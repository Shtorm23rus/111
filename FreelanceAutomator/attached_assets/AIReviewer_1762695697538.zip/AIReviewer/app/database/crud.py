from sqlalchemy.orm import Session
from typing import List, Optional, Dict, Any
from app.database.models import Job, GeneratedContent
from app.utils.logger import get_logger

logger = get_logger(__name__)

def create_job(db: Session, job_data: Dict[str, Any]) -> Job:
    job = Job(**job_data)
    db.add(job)
    db.commit()
    db.refresh(job)
    logger.info(f"Created job: {job.job_id}")
    return job

def get_job_by_id(db: Session, job_id: str) -> Optional[Job]:
    return db.query(Job).filter(Job.job_id == job_id).first()

def get_all_jobs(db: Session, skip: int = 0, limit: int = 100) -> List[Job]:
    return db.query(Job).offset(skip).limit(limit).all()

def get_jobs_by_status(db: Session, status: str) -> List[Job]:
    return db.query(Job).filter(Job.status == status).all()

def update_job_status(db: Session, job_id: str, status: str) -> Optional[Job]:
    job = get_job_by_id(db, job_id)
    if job:
        job.status = status
        db.commit()
        db.refresh(job)
        logger.info(f"Updated job {job_id} status to {status}")
    return job

def create_generated_content(db: Session, job_id: str, content_type: str, text: str) -> GeneratedContent:
    content = GeneratedContent(
        job_id=job_id,
        content_type=content_type,
        generated_text=text
    )
    db.add(content)
    db.commit()
    db.refresh(content)
    logger.info(f"Created generated content for job: {job_id}")
    return content

def get_content_by_job_id(db: Session, job_id: str) -> List[GeneratedContent]:
    return db.query(GeneratedContent).filter(GeneratedContent.job_id == job_id).all()

def delete_job(db: Session, job_id: str) -> bool:
    job = get_job_by_id(db, job_id)
    if job:
        db.delete(job)
        db.commit()
        logger.info(f"Deleted job: {job_id}")
        return True
    return False
